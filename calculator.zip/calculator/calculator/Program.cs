﻿using System;

namespace Calculator
{
    class Program
    {
        static void Main(string[] args)
        {
            // Declare variables and then initialize to zero.
            int num1 = 0; int num2 = 0;

            //first number.
            Console.WriteLine("Type a number1, and then press Enter");
            num1 = Convert.ToInt32(Console.ReadLine());

            //second number.
            Console.WriteLine("Type number2, and then press Enter");
            num2 = Convert.ToInt32(Console.ReadLine());

            // Ask the user to choose an option.
            Console.WriteLine("Choose an option from the following list:");
            Console.WriteLine("\t+ - Add");
            Console.WriteLine("\t- - Subtract");
            Console.WriteLine("\t* - Multiply");
            Console.WriteLine("\t/ - Divide");
            Console.Write("Your option? ");

            //switch to calculte inputs form user.
            switch (Console.ReadLine())
            {
                case "+":
                    Console.WriteLine($"Result: {num1} + {num2} = " + (num1 + num2));
                    break;
                case "-":
                    Console.WriteLine($"Result: {num1} - {num2} = " + (num1 - num2));
                    break;
                case "*":
                    Console.WriteLine($"Result: {num1} * {num2} = " + (num1 * num2));
                    break;
                case "/":
                    Console.WriteLine($"Result: {num1} / {num2} = " + (num1 / num2));
                    break;
            }

            Console.ReadKey();
        }
    }
}
